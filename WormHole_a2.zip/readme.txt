It's like snake!

Controls:
WASD to move
Q to quit

Character key:
H - Worm head
w - Worm tail
W - Worm tail (fat)
? - Delicious mushroom
purple - Mycelium

Made by BadRAM