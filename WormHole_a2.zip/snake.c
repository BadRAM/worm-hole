#include <ncurses.h>
#include <stdlib.h>

// World Tile Content Definitions

// Floor Tiles
#define EMPTY_TILE 0
#define BARE_STONE 1
#define MYCELIUM 2
#define WEEDS 3
#define FLOOR_TILE_BITMASK 3

// Objects
#define OBJECT_BITMASK 0xFC

#define PLAYER 0x10

#define MUSHROOM 0x40
#define FLOWER   0x44

#define DUNGBALL 0x5C
#define DUNGBALL_ROLLING_UP    0x60
#define DUNGBALL_ROLLING_DOWN  0x64
#define DUNGBALL_ROLLING_LEFT  0x68
#define DUNGBALL_ROLLING_RIGHT 0x6C

#define SLUG_BABY 0x90
#define SLUG_EGGS 0x94
#define SLIME     0x98

#define SLUG_HEAD_UP    0XA0
#define SLUG_HEAD_DOWN  0XA4
#define SLUG_HEAD_LEFT  0XA8
#define SLUG_HEAD_RIGHT 0XAC

#define SLUG_TAIL_UP    0XB0
#define SLUG_TAIL_DOWN  0XB4
#define SLUG_TAIL_LEFT  0XB8
#define SLUG_TAIL_RIGHT 0XBC


// NOFLOOR objects
#define WORM_TAIL       0xD0
#define WORM_TAIL_UP    0xD0
#define WORM_TAIL_DOWN  0xD1
#define WORM_TAIL_LEFT  0xD2
#define WORM_TAIL_RIGHT 0xD3

#define WORM_TAIL_FAT       0xD4
#define WORM_TAIL_FAT_UP    0xD4
#define WORM_TAIL_FAT_DOWN  0xD5
#define WORM_TAIL_FAT_LEFT  0xD6
#define WORM_TAIL_FAT_RIGHT 0xD7 

#define WORM_HEAD       0xD8
#define WORM_HEAD_UP    0xD8
#define WORM_HEAD_DOWN  0xD9
#define WORM_HEAD_LEFT  0xDA
#define WORM_HEAD_RIGHT 0xDB

// Direction bits for NOFLOOR, DIRECTIONAL type tiles (mostly worm segments)
#define DIRECTION_BITMASK 0b11
#define UP    0
#define DOWN  1
#define LEFT  2
#define RIGHT 3

// POPFLAGs, used to check if a certain population is zero
#define MYCELIUM_POPFLAG 1 //0b00000001
#define WEEDS_POPFLAG    0b00000010
#define SLUG_POPFLAG     0b00000100

// World size definitions
#define WORLD_WIDTH 64
#define WORLD_HEIGHT 30
#define RANDOM_TICKS WORLD_WIDTH * WORLD_HEIGHT / 10

struct xy
{
    int x, y;
};

// Define Variables
char ch; // this variable stores the last input
int world[WORLD_WIDTH][WORLD_HEIGHT] = {0};
int world_new[WORLD_WIDTH][WORLD_HEIGHT] = {0};
int popflags = 0; // population flags, used to check for extinction
int score = 0;

// Prototypes
void init();
bool loop();
void update_cell(int x, int y);
void random_tick(int x, int y);
void repopulate(int tile);
void worm_head(int x, int y);
int char_to_dir(char c);
struct xy worm_next_tile(int x, int y);
bool tile_empty(int x, int y);
void buffer_world();
int cell_neighbors(int x, int y);
void render();

int main()
{   
    init();

    // Game Loop
    while (loop())
    {
        // idk we already did everything we wanted to.
    }

    endwin();           /* End curses mode        */

    return 0;
}

void init()
{
    // Initialize ncurses
    initscr();          /* Start curses mode        */

    if(has_colors() == FALSE)
    {   endwin();
        printf("Your terminal does not support color\n");
        exit(1);
    }

    start_color();
    // init_color(COLOR_GREEN, 50, 200, 50);
    // init_color(COLOR_RED, 200, 50, 150);
    init_pair(1, COLOR_WHITE, COLOR_BLACK);
    init_pair(2, COLOR_BLACK, COLOR_WHITE);
    init_pair(3, COLOR_WHITE, COLOR_MAGENTA);
    init_pair(4, COLOR_WHITE, COLOR_GREEN);

    raw();              /* Line buffering disabled  */
    keypad(stdscr, TRUE);       /* We get F1, F2 etc..      */
    noecho();           /* Don't echo() while we do getch */
    erase();
    curs_set(0);

    move(1, WORLD_WIDTH + 1);
    printw("RANDOM_TICKS: ");    
    char str[10];
    sprintf(str, "%d", RANDOM_TICKS);
    printw(str);   


    world_new[2][2]  = WORM_HEAD_RIGHT;
    world_new[3][2]  = WORM_TAIL_RIGHT;
    world_new[4][2]  = WORM_TAIL_RIGHT;
    world_new[5][2]  = WORM_TAIL_RIGHT;
    world_new[6][2]  = WORM_TAIL_RIGHT;
    world_new[7][2]  = WORM_TAIL_RIGHT;
    world_new[8][2]  = WORM_TAIL_RIGHT;
    world_new[9][2]  = WORM_TAIL_RIGHT;
    world_new[10][2] = WORM_TAIL_RIGHT;
    world_new[11][2] = WORM_TAIL_RIGHT;

    //world_new[14][4] = MUSHROOM;
    //world_new[15][7] = MYCELIUM;

    buffer_world();
}

bool loop()
{
    // Render
    render();
    
    // Wait for input
    ch = getch();

    move(2, WORLD_WIDTH + 1);
    printw("LAST INPUT: ");
    addch(ch);

    move(3, WORLD_WIDTH + 1);
    printw("POPFLAGS: ");
    char str[8];
    sprintf(str, "%d", popflags);
    printw(str); 

    move(4, WORLD_WIDTH + 1);
    printw("SCORE: ");
    sprintf(str, "%d", score);
    printw(str); 
    
    // Process input
    if (ch == 'q')
    {
        return false;
    }
    

    // Update world
    popflags = 0;
    for (int x = 0; x < WORLD_WIDTH; x++)
    {
        for (int y = 0; y < WORLD_HEIGHT; y++)
        {
            update_cell(x, y);
        }
    }

    for (int i = 0; i < RANDOM_TICKS; ++i)
    {
        random_tick(rand() % WORLD_WIDTH, rand() % WORLD_HEIGHT);
    }

    if ((popflags & MYCELIUM_POPFLAG) == 0) repopulate(MYCELIUM);


    buffer_world();

    return true;
}


void update_cell(int x, int y)
{
    switch (world[x][y] & FLOOR_TILE_BITMASK)
    {
        case MYCELIUM:
            popflags |= MYCELIUM_POPFLAG;
            break;
        case WEEDS:
            popflags |= WEEDS_POPFLAG;
            break;
        default: 
            break;
    }
    switch (world[x][y] & OBJECT_BITMASK)
    {
        case EMPTY_TILE:
            break;
        // case WALL:
        // case BEDROCK:


        case WORM_HEAD:
            worm_head(x, y);
            break;

        // case PLAYER:
        // case SLIME:
        // case BOULDER:
        // case SLUG:
        case MUSHROOM:
            break;
    }
}

void random_tick(int x, int y)
{
        switch (world[x][y])
    {
        case EMPTY_TILE:
            if (tile_empty(x, y))
            {
                int ne = cell_neighbors(x, y);
                if (ne >= 1 && ne <= (rand()%7)+1)
                {
                    world_new[x][y] = MYCELIUM;
                }
            }
            break;

        case MYCELIUM:
            int nm = cell_neighbors(x, y);
            if (nm == 8)
            {
                world_new[x][y] |= MUSHROOM;
            }
            break;
    }
}

void repopulate(int tile)
{
    int x = rand() % WORLD_WIDTH;
    int y = rand() % WORLD_HEIGHT;

    if (tile_empty(x, y))
    {
        world_new[x][y] = tile;
    }
}

void worm_head(int x, int y)
{
    struct xy to = {x,y};

    switch (ch)
    {
        case 'w':
            to.y--;
            break;
        case 's':
            to.y++;
            break;
        case 'a':
            to.x--;
            break;
        case 'd':
            to.x++;
            break;
    }

    bool has_moved = false;

    if (tile_empty(to.x, to.y))
    {
        world_new[to.x][to.y] = WORM_HEAD | char_to_dir(ch);
        has_moved = true;
    }

    if (has_moved)
    {
        if ((world[to.x][to.y] & OBJECT_BITMASK) == MUSHROOM)
        {
            score++;
            has_moved = false;
            world_new[x][y] = (world[x][y] & DIRECTION_BITMASK) | WORM_TAIL_FAT;
        } 
        else 
        {
            world_new[x][y] = (world[x][y] & DIRECTION_BITMASK) | WORM_TAIL;
        }
    }

    if (has_moved)
    {
        struct xy prev;
        prev.x = x;
        prev.y = y;
        bool prev_fat = false;
        struct xy next;
        while (true)
        {
            // If the end of the worm is detected
            next = worm_next_tile(prev.x, prev.y);
            if ((world[next.x][next.y] & OBJECT_BITMASK) != WORM_TAIL && 
                (world[next.x][next.y] & OBJECT_BITMASK) != WORM_TAIL_FAT)
            {
                // set the tile to empty if normal, dungball if fat.
                world_new[prev.x][prev.y] = (world_new[prev.x][prev.y] & OBJECT_BITMASK) != WORM_TAIL_FAT ? EMPTY_TILE : DUNGBALL;
                break;
            } 
            else if ((world[prev.x][prev.y] & OBJECT_BITMASK) == WORM_TAIL_FAT)
            {
                world_new[prev.x][prev.y] = (prev_fat ? WORM_TAIL_FAT : WORM_TAIL) | (world_new[prev.x][prev.y] & DIRECTION_BITMASK);
                world_new[next.x][next.y] = WORM_TAIL_FAT | (world_new[next.x][next.y] & DIRECTION_BITMASK);
                prev_fat = true;
            }
            else
            {
                prev_fat = false;
            }
            prev = next;
        }
    }
}


int char_to_dir(char c)
{
    switch (c)
    {
        case 'w':
            return DOWN;
        case 's':
            return UP;
        case 'a':
            return RIGHT;
        case 'd':
            return LEFT;
    }
    return 0;
}

// Get the position of the next tile in a worm.
struct xy worm_next_tile(int x, int y)
{
    struct xy pos;
    pos.x = x;
    pos.y = y;
    switch (world[x][y] & FLOOR_TILE_BITMASK)
    {
        case 0:
            pos.y = y-1;
            break;
        case 1:
            pos.y = y+1;
            break;
        case 2:
            pos.x = x-1;
            break;
        case 3:
            pos.x = x+1;
            break;
    }
    return pos;
}

// Get the position of the previous tile in a worm. returns input if none can be found.
struct xy worm_prev_tile(int x, int y)
{
    struct xy r = {x,y};
    if (world[x][y-1] & DIRECTION_BITMASK == DOWN)
    {
        r.y--;
    }
    else if (world[x][y+1] & DIRECTION_BITMASK == UP)
    {
        r.y++;
    }
    else if (world[x-1][y] & DIRECTION_BITMASK == RIGHT)
    {
        r.x--;
    }
    else if (world[x+1][y] & DIRECTION_BITMASK == LEFT)
    {
        r.x++;
    }
    return r;
}

bool tile_empty(int x, int y)
{
    // block out of bounds
    if (x < 0 || x >= WORLD_WIDTH || y < 0 || y >= WORLD_HEIGHT)
    {
        return false;
    }

    int tile = world[x][y] & OBJECT_BITMASK;
    for (int i = 0; i < 2; ++i) // this runs twice.
    {
        if ((tile != MUSHROOM) && (tile != 0)) 
        {
            return false;
        }
        tile = world_new[x][y] & OBJECT_BITMASK;
    }
    return true;
}

void buffer_world()
{
    for (int x = 0; x < WORLD_WIDTH; x++)
    {
        for (int y = 0; y < WORLD_HEIGHT; y++)
        {
            world[x][y] = world_new[x][y];
        }
    }
}

//Game of life style count of living neighbors to cell
int cell_neighbors(int x, int y)
{
    int r = 0;

    for(int nx = x-1; nx <= x+1; nx++)
    {
        for(int ny = y-1; ny <= y+1; ny++)
        {
            if ((nx == x && ny == y) || nx < 0 || ny < 0 || nx >= WORLD_WIDTH || ny >= WORLD_HEIGHT)
            {
                continue;
            }
            // move(8, WORLD_WIDTH+2);
            // printw("OK!");
            r += world[nx][ny] == MYCELIUM ? 1 : 0;
        }
    }
    return r;
}

void render()
{
    for (int x = 0; x < WORLD_WIDTH; x++)
    {
        for (int y = 0; y < WORLD_HEIGHT; y++)
        {
            int col = 1;
            if ((world[x][y] & 0xC0) == 0xC0)
            {
                col = 2;
            }
            else
            {
                col = (world[x][y] & FLOOR_TILE_BITMASK)+1;
            }
            attron(COLOR_PAIR(col));
            move(y, x);
            switch (world[x][y] & OBJECT_BITMASK)
            {
                case EMPTY_TILE:
                    addch('.');
                    break;

                case WORM_TAIL:
                    addch('w');
                    break;

                case WORM_TAIL_FAT:
                    addch('W');
                    break;

                case WORM_HEAD:
                    addch('H');
                    break;

                // case PLAYER:
                case SLIME:
                    addch('_');
                    break;

                case DUNGBALL:
                    addch('O');
                    break;

                case SLUG_BABY:
                    addch('S');
                    break;

                case MUSHROOM:
                    addch('?');
                    break;
            }
            attroff(COLOR_PAIR(col));
        }
    }
}