It's like snake!

Controls:
WASD to move
Q to quit

Character key:
. - Empty
H - Worm head
w - Worm tail
W - Worm tail (fat)
s - Slug
_ - Slime
? - Delicious mushroom
* - Flower
O - Dungball
Background color key:
purple - Mycelium
green - Weeds

Made by BadRAM