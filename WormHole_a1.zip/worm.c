#include <ncurses.h>
#include <stdlib.h>

// World Tile Content Definitions
#define EMPTY_TILE 0
#define BARE_STONE 1
#define MYCELIUM 2
#define WEEDS 3
#define FLOOR_TILE_BITMASK 3


#define DIRECTION_BITMASK 0b11
#define UP    0
#define DOWN  1
#define LEFT  2
#define RIGHT 3

// Objects
#define OBJECT_BITMASK 0xFC
#define TAIL       0xD0
#define TAIL_UP    0xD0
#define TAIL_DOWN  0xD1
#define TAIL_LEFT  0xD2
#define TAIL_RIGHT 0xD3

#define HEAD_UP    0xD4
#define HEAD_DOWN  0xD5
#define HEAD_LEFT  0xD6
#define HEAD_RIGHT 0xD7

// #define PLAYER 128
// #define SLIME 129
// #define BOULDER 130
// #define SLUG 200

#define MUSHROOM 255

// POPFLAGs, used to check if a certain population is zero
#define MYCELIUM_POPFLAG 0b00000001
#define SLUG_POPFLAG     0b00000010

// World size definitions
#define WORLD_WIDTH 64
#define WORLD_HEIGHT 30
#define RANDOM_TICKS WORLD_WIDTH * WORLD_HEIGHT / 10

struct xy
{
    int x, y;
};

// Define Variables
char ch; // this variable stores the last input
int world[WORLD_WIDTH][WORLD_HEIGHT] = {0};
int world_new[WORLD_WIDTH][WORLD_HEIGHT] = {0};
int popflags = 0; // population flags, used to check for extinction

// Prototypes
void init();
bool loop();
void update_cell(int x, int y);
void random_tick(int x, int y);
void worm_head(int x, int y);
struct xy worm_next_tile(int x, int y);
bool tile_empty(int x, int y);
void buffer_world();
int cell_neighbors(int x, int y);
void render();

int main()
{   
    init();

    // Game Loop
    while (loop())
    {
        // idk we already did everything we wanted to.
    }

    endwin();           /* End curses mode        */

    return 0;
}

void init()
{
    // Initialize ncurses
    initscr();          /* Start curses mode        */
    raw();              /* Line buffering disabled  */
    keypad(stdscr, TRUE);       /* We get F1, F2 etc..      */
    noecho();           /* Don't echo() while we do getch */
    erase();
    curs_set(0);

    move(1, WORLD_WIDTH + 1);
    printw("RANDOM_TICKS:");    
    move(2, WORLD_WIDTH + 1);
    char str[10];
    sprintf(str, "%d", RANDOM_TICKS);
    printw(str);


    world_new[2][2]  = HEAD_RIGHT;
    world_new[3][2]  = TAIL_RIGHT;
    world_new[4][2]  = TAIL_RIGHT;
    world_new[5][2]  = TAIL_RIGHT;
    world_new[6][2]  = TAIL_RIGHT;
    world_new[7][2]  = TAIL_RIGHT;
    world_new[8][2]  = TAIL_RIGHT;
    world_new[9][2]  = TAIL_RIGHT;
    world_new[10][2] = TAIL_RIGHT;
    world_new[11][2] = TAIL_RIGHT;

    //world_new[14][4] = MUSHROOM;
    world_new[15][7] = MYCELIUM;
    buffer_world();
}

bool loop()
{
    // Render
    render();
    
    // Wait for input
    ch = getch();

    move(4, WORLD_WIDTH + 1);
    addch(ch);
    
    // Process input
    if (ch == 'q')
    {
        return false;
    }
    

    // Update world
    popflags = 0;
    for (int x = 0; x < WORLD_WIDTH; x++)
    {
        for (int y = 0; y < WORLD_HEIGHT; y++)
        {
            update_cell(x, y);
        }
    }

    for (int i = 0; i < RANDOM_TICKS; ++i)
    {
        random_tick(rand() % WORLD_WIDTH, rand() % WORLD_HEIGHT);
    }

    if ((popflags & MYCELIUM_POPFLAG) == 0)
    {
        int x = rand() % WORLD_WIDTH;
        int y = rand() % WORLD_HEIGHT;

        if (tile_empty(x, y))
        {
            world_new[x][y] = MYCELIUM;
        }
    }

    buffer_world();

    return true;
}


void update_cell(int x, int y)
{
    switch (world[x][y])
    {
        case EMPTY_TILE:
            break;
        // case WALL:
        // case BEDROCK:


        case HEAD_UP:
        case HEAD_DOWN:
        case HEAD_LEFT:
        case HEAD_RIGHT:
            worm_head(x, y);
            break;


        // case PLAYER:
        // case SLIME:
        // case BOULDER:
        // case SLUG:
        case MYCELIUM:
            popflags |= MYCELIUM_POPFLAG;
            break;
        case MUSHROOM:
            break;
    }
}

void random_tick(int x, int y)
{
        switch (world[x][y])
    {
        case EMPTY_TILE:
            if (tile_empty(x, y))
            {
                int ne = cell_neighbors(x, y);
                if (ne >= 1 && ne <= (rand()%7)+1)
                {
                    world_new[x][y] = MYCELIUM;
                }
            }
            break;

        case MYCELIUM:
            int nm = cell_neighbors(x, y);
            if (nm == 8)
            {
                world_new[x][y] = MUSHROOM;
            }
            break;
    }
}

void worm_head(int x, int y)
{
    bool has_moved = false;
    if (ch == 'w' && tile_empty(x,y-1))
    {
        world_new[x][y-1] = HEAD_DOWN;
        world_new[x][y] = (world[x][y] & DIRECTION_BITMASK) | TAIL;
        has_moved = world[x][y-1] != MUSHROOM;
    }
    if (ch == 's' && tile_empty(x,y+1))
    {
        world_new[x][y+1] = HEAD_UP;
        world_new[x][y] = (world[x][y] & DIRECTION_BITMASK) | TAIL;
        has_moved = world[x][y+1] != MUSHROOM;
    }
    if (ch == 'a' && tile_empty(x-1,y))
    {
        world_new[x-1][y] = HEAD_RIGHT;
        world_new[x][y] = (world[x][y] & DIRECTION_BITMASK) | TAIL;
        has_moved = world[x-1][y] != MUSHROOM;
    }
    if (ch == 'd' && tile_empty(x+1,y))
    {
        world_new[x+1][y] = HEAD_LEFT;
        world_new[x][y] = (world[x][y] & DIRECTION_BITMASK) | TAIL;
        has_moved = world[x+1][y] != MUSHROOM;
    }

    if (has_moved)
    {
        struct xy prev;
        prev.x = x;
        prev.y = y;
        struct xy next;
        while (true)
        {
            next = worm_next_tile(prev.x, prev.y);
            if ((world[next.x][next.y] & OBJECT_BITMASK) != TAIL)
            {
                world_new[prev.x][prev.y] = EMPTY_TILE;
                break;
            }
            prev = next;
        }
    }
}

// Get the position of the next tile in a worm.
struct xy worm_next_tile(int x, int y)
{
    struct xy pos;
    pos.x = x;
    pos.y = y;
    switch (world[x][y] & FLOOR_TILE_BITMASK)
    {
        case 0:
            pos.y = y-1;
            break;
        case 1:
            pos.y = y+1;
            break;
        case 2:
            pos.x = x-1;
            break;
        case 3:
            pos.x = x+1;
            break;
    }
    return pos;
}

bool tile_empty(int x, int y)
{
    // block out of bounds
    if (x < 0 || x >= WORLD_WIDTH || y < 0 || y >= WORLD_HEIGHT)
    {
        return false;
    }

    int tile = world[x][y];
    for (int i = 0; i < 2; ++i) // this runs twice.
    {
        if (tile != MUSHROOM && tile > FLOOR_TILE_BITMASK) 
        {
            return false;
        }

        tile = world_new[x][y];
    }
    return true;
}

void buffer_world()
{
    for (int x = 0; x < WORLD_WIDTH; x++)
    {
        for (int y = 0; y < WORLD_HEIGHT; y++)
        {
            world[x][y] = world_new[x][y];
        }
    }
}

//Game of life style count of living neighbors to cell
int cell_neighbors(int x, int y)
{
    int r = 0;

    for(int nx = x-1; nx <= x+1; nx++)
    {
        for(int ny = y-1; ny <= y+1; ny++)
        {
            if ((nx == x && ny == y) || nx < 0 || ny < 0 || nx >= WORLD_WIDTH || ny >= WORLD_HEIGHT)
            {
                continue;
            }
            // move(8, WORLD_WIDTH+2);
            // printw("OK!");
            r += world[nx][ny] == MYCELIUM ? 1 : 0;
        }
    }

    return r;
}

void render()
{
    for (int x = 0; x < WORLD_WIDTH; x++)
    {
        for (int y = 0; y < WORLD_HEIGHT; y++)
        {
            move(y, x);
            switch (world[x][y])
            {
                case EMPTY_TILE:
                    addch('.');
                    break;

                // case WALL:
                // case BEDROCK:
                case TAIL_UP:
                case TAIL_DOWN:
                case TAIL_LEFT:
                case TAIL_RIGHT:
                    addch('W');
                    break;

                case HEAD_UP:
                case HEAD_DOWN:
                case HEAD_LEFT:
                case HEAD_RIGHT:
                    addch('H');
                    break;

                // case PLAYER:
                // case SLIME:
                // case BOULDER:
                // case SLUG:
                case MYCELIUM:
                    addch('_');
                    break;
                case MUSHROOM:
                    addch('?');
                    break;
                    
                default:
                    break;
            }
        }
    }
}