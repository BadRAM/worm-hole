It's like snake!

Controls:
WASD to move
Q to quit

Character key:
H - Worm head
W - Worm tail
? - Delicious mushroom
_ - Mycelium
. - Empty floor

Made by BadRAM